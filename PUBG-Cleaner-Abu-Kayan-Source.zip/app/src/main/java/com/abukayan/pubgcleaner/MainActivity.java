package com.abukayan.pubgcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.documentfile.provider.DocumentFile;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_FOLDER = 42;
    private static final int NAVY = Color.rgb(10,18,36);
    private static final int CARD = Color.rgb(18,33,55);
    private static final int BLUE = Color.rgb(19,145,240);
    private static final int GOLD = Color.rgb(247,191,49);
    private static final int MUTED = Color.rgb(175,193,212);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayList<DocumentFile> candidates = new ArrayList<>();
    private Uri folderUri;
    private TextView status, location;
    private Button scanButton, cleanButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        buildUi();
        SharedPreferences p = getSharedPreferences("cleaner",MODE_PRIVATE);
        String saved = p.getString("folder",null);
        if (saved != null) {
            try {
                folderUri = Uri.parse(saved);
                location.setText("المجلد المحدد: " + folderUri.getLastPathSegment());
                scanButton.setEnabled(true);
            } catch (Exception ignored) { folderUri = null; }
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(NAVY);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(20),dp(23),dp(20),dp(26));
        scroll.addView(root);
        setContentView(scroll);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.abu_kayan_icon);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(142),dp(142));
        logoLp.bottomMargin=dp(10);
        root.addView(logo,logoLp);
        addText(root,"PUBG CLEANER",27,GOLD,true,Gravity.CENTER);
        addText(root,"أبو كيان | تنظيف آمن للملفات المؤقتة",16,Color.WHITE,true,Gravity.CENTER);
        addText(root,"أنت تختار المجلد، ولن نحذف أي ملفات بدون موافقتك.",13,MUTED,false,Gravity.CENTER);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16),dp(18),dp(16),dp(18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1,-2);
        cardLp.topMargin=dp(20);
        card.setBackground(shape(CARD,BLUE,1));
        root.addView(card,cardLp);
        addText(card,"تنظيف الملفات المؤقتة",20,GOLD,true,Gravity.RIGHT);
        addText(card,"يفحص ملفات .tmp و .temp و .log فقط في المجلد الذي تسمح للتطبيق بفتحه.",13,MUTED,false,Gravity.RIGHT);
        location=addText(card,"لم يتم اختيار مجلد",13,Color.WHITE,false,Gravity.RIGHT);
        addButton(card,"١  •  اختيار مجلد",BLUE,() -> chooseFolder());
        scanButton=addButton(card,"٢  •  فحص الملفات",GOLD,() -> scan());
        scanButton.setEnabled(false);
        cleanButton=addButton(card,"٣  •  مراجعة وحذف",GOLD,() -> confirmDelete());
        cleanButton.setEnabled(false);
        status=addText(card,"جاهز. اختر مجلدًا للبدء.",14,Color.WHITE,false,Gravity.RIGHT);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1,-2);
        infoLp.topMargin=dp(18);
        info.setBackground(shape(CARD,GOLD,1));
        root.addView(info,infoLp);
        addText(info,"نصائح لتحسين الأداء",18,GOLD,true,Gravity.RIGHT);
        addText(info,"• اترك مساحة تخزين فارغة كافية.\n• أغلق التطبيقات الثقيلة قبل اللعب.\n• لا تحذف ملفات اللعبة الأساسية أو بيانات الحفظ.\n• لا يتجاوز التطبيق قيود أندرويد على الملفات المحمية.",14,Color.WHITE,false,Gravity.RIGHT);
        addButton(root,"تواصل مع المطور عبر Telegram",BLUE,() -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://t.me/OmarVIP3"))); }
            catch(Exception ignored) { status.setText("تعذر فتح رابط المطور."); }
        });
        addText(root,"Abu Kayan • إصدار تجريبي آمن",12,MUTED,false,Gravity.CENTER);
    }

    private void chooseFolder() {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(picker,REQUEST_FOLDER); }
        catch(Exception ignored) { status.setText("تعذر فتح منتقي المجلدات."); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode!=REQUEST_FOLDER || resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        folderUri=data.getData();
        int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(folderUri,flags); }
        catch(Exception ignored) { }
        getSharedPreferences("cleaner",MODE_PRIVATE).edit().putString("folder",folderUri.toString()).apply();
        candidates.clear();
        cleanButton.setEnabled(false);
        scanButton.setEnabled(true);
        location.setText("المجلد: "+folderUri.getLastPathSegment());
        status.setText("تم الاختيار. اضغط فحص الملفات.");
    }

    private void scan() {
        if (folderUri==null) return;
        final Uri chosen=folderUri;
        scanButton.setEnabled(false);
        cleanButton.setEnabled(false);
        status.setText("جارٍ الفحص...");
        worker.execute(() -> {
            ArrayList<DocumentFile> found=new ArrayList<>();
            int[] seen={0};
            String failure=null;
            try {
                DocumentFile root=DocumentFile.fromTreeUri(this,chosen);
                if (root==null || !root.canRead()) throw new SecurityException();
                walk(root,0,seen,found);
            } catch(Exception e) { failure="المجلد غير متاح. اختره من جديد."; }
            long bytes=0;
            StringBuilder example=new StringBuilder();
            for (int i=0;i<found.size();i++) {
                DocumentFile file=found.get(i);
                bytes+=Math.max(0,file.length());
                if (i<5) example.append("\n• ").append(file.getName());
            }
            final long total=bytes;
            final String names=example.toString();
            final String error=failure;
            runOnUiThread(() -> {
                if(!chosen.equals(folderUri)) return;
                candidates.clear(); candidates.addAll(found);
                scanButton.setEnabled(true);
                cleanButton.setEnabled(!found.isEmpty() && error==null);
                if(error!=null) { status.setText(error); return; }
                status.setText("تم فحص "+seen[0]+" عنصرًا. الملفات المؤقتة: "+found.size()+
                    " | الحجم التقريبي: "+human(total)+names+"\nلن يحذف التطبيق شيئًا إلا بعد التأكيد.");
            });
        });
    }

    private void walk(DocumentFile dir,int depth,int[] seen,ArrayList<DocumentFile> found) {
        if(depth>8 || seen[0]>=5000) return;
        DocumentFile[] files;
        try { files=dir.listFiles(); } catch(Exception e) { return; }
        for(DocumentFile f:files) {
            if(++seen[0]>5000) return;
            if(f.isDirectory()) walk(f,depth+1,seen,found);
            else if(f.isFile()) {
                String name=f.getName();
                if(name==null) continue;
                String n=name.toLowerCase(Locale.ROOT);
                if(n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".log")) found.add(f);
            }
        }
    }

    private void confirmDelete() {
        if(candidates.isEmpty()) return;
        new AlertDialog.Builder(this)
            .setTitle("تأكيد الحذف")
            .setMessage("سيتم حذف "+candidates.size()+" ملف مؤقت من المجلد الذي اخترته. بعض ملفات السجل قد تكون مفيدة لتشخيص الأخطاء. الحذف لا يمكن التراجع عنه. متابعة؟")
            .setNegativeButton("إلغاء",(d,w)->{})
            .setPositiveButton("حذف",(d,w)->deleteSelected())
            .show();
    }

    private void deleteSelected() {
        final ArrayList<DocumentFile> deleting=new ArrayList<>(candidates);
        cleanButton.setEnabled(false);
        scanButton.setEnabled(false);
        status.setText("جارٍ الحذف بعد موافقتك...");
        worker.execute(() -> {
            int count=0;
            for(DocumentFile file:deleting) {
                try { if(file.delete()) count++; } catch(Exception ignored) { }
            }
            final int done=count;
            runOnUiThread(() -> {
                candidates.clear();
                scanButton.setEnabled(folderUri!=null);
                status.setText("تم حذف "+done+" من "+deleting.size()+" ملف. يمكنك إعادة الفحص.");
            });
        });
    }

    private String human(long bytes) {
        if(bytes<1024) return bytes+" B";
        if(bytes<1048576) return bytes/1024+" KB";
        return String.format(Locale.US,"%.1f MB",bytes/1048576.0);
    }
    private TextView addText(LinearLayout parent,String value,int size,int color,boolean bold,int gravity) {
        TextView t=new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(gravity); t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setPadding(dp(4),dp(7),dp(4),dp(7));
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        parent.addView(t,new LinearLayout.LayoutParams(-1,-2));
        return t;
    }
    private Button addButton(LinearLayout parent,String value,int color,Runnable cb) {
        Button b=new Button(this); b.setText(value); b.setAllCaps(false); b.setTextSize(15);
        b.setTextColor(color==GOLD?NAVY:Color.WHITE);
        b.setBackground(shape(color,color,0));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(53)); p.topMargin=dp(11);
        parent.addView(b,p); b.setOnClickListener(v->cb.run()); return b;
    }
    private GradientDrawable shape(int bg,int border,int thickness) {
        GradientDrawable d=new GradientDrawable(); d.setColor(bg); d.setCornerRadius(dp(12));
        if(thickness>0) d.setStroke(dp(thickness),border);
        return d;
    }
    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density*v); }
    @Override protected void onDestroy() { worker.shutdown(); super.onDestroy(); }
}

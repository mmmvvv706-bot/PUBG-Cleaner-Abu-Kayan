# PUBG Cleaner - Abu Kayan

Prototype Android application for user-approved cleaning of temporary files in user-selected directories.

- Does not require root or Shizuku.
- Android Storage Access Framework: user selects a folder.
- Scans only .tmp, .temp and .log extensions; checks no more than 5,000 entries and depth 8.
- Shows results and requires explicit confirmation to delete.
- Protected game files are not accessible and are never modified by this prototype.
- Developer Telegram: https://t.me/OmarVIP3

Build with Gradle 8.9, Android Gradle Plugin 8.7.3, Java 17, Android SDK 35.

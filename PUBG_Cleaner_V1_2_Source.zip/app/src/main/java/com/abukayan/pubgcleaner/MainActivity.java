package com.abukayan.pubgcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {
    private static final int REQUEST_FOLDER = 42;
    private static final int NAVY = Color.rgb(9, 17, 34);
    private static final int CARD = Color.rgb(18, 32, 54);
    private static final int BLUE = Color.rgb(22, 137, 232);
    private static final int GOLD = Color.rgb(246, 190, 54);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(177, 194, 214);

    private final ExecutorService worker = Executors.newFixedThreadPool(2);
    private final ArrayList<DocumentFile> candidates = new ArrayList<>();
    private Uri folderUri;

    private TextView scanStatus, folderLabel, localIpValue, publicIpValue;
    private Button scanButton, cleanButton, refreshIpButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        buildUi();

        String saved = getSharedPreferences("cleaner", MODE_PRIVATE).getString("folder", null);
        if (saved != null) {
            try {
                folderUri = Uri.parse(saved);
                DocumentFile selected = DocumentFile.fromTreeUri(this, folderUri);
                folderLabel.setText(selected != null && selected.getName() != null
                        ? "المجلد المحدد: " + selected.getName() : "تم حفظ المجلد المحدد");
                scanButton.setEnabled(true);
                cleanButton.setEnabled(true);
            } catch (Exception ignored) { folderUri = null; }
        }
        refreshIpInfo();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(NAVY);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(18), dp(20), dp(18), dp(26));
        scroll.addView(root);
        setContentView(scroll);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.abu_kayan_icon);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(dp(126), dp(126)));

        addText(root, "PUBG CLEANER", 27, GOLD, true, Gravity.CENTER);
        addText(root, "أبو كيان | أدوات تنظيف وشبكة", 17, WHITE, true, Gravity.CENTER);
        addText(root, "أدوات واضحة وآمنة — لا يتم تعديل ملفات اللعبة المحمية.", 13, MUTED, false, Gravity.CENTER);

        LinearLayout network = makeCard(root);
        addText(network, "معلومات عناوين IP", 20, GOLD, true, Gravity.RIGHT);
        addText(network, "IP الجهاز داخل الشبكة", 13, MUTED, true, Gravity.RIGHT);
        localIpValue = addText(network, "جارٍ قراءة العنوان...", 16, WHITE, true, Gravity.RIGHT);
        localIpValue.setOnClickListener(v -> copyIp("IP الجهاز", localIpValue.getText().toString()));

        addText(network, "IP الإنترنت العام", 13, MUTED, true, Gravity.RIGHT);
        publicIpValue = addText(network, "جارٍ جلب العنوان...", 16, WHITE, true, Gravity.RIGHT);
        publicIpValue.setOnClickListener(v -> copyIp("IP الإنترنت", publicIpValue.getText().toString()));

        refreshIpButton = addButton(network, "تحديث عناوين IP", BLUE, this::refreshIpInfo);
        addButton(network, "إعدادات Wi-Fi (إعادة الاتصال)", GOLD, this::openWifiSettings);
        addButton(network, "إعدادات VPN", BLUE, this::openVpnSettings);
        addText(network,
                "التطبيق يعرض العناوين ويفتح إعدادات الهاتف. تغيير IP العام يحتاج VPN موثوقًا أو تغيير الشبكة؛ لا يوجد خادم VPN مدمج.",
                12, MUTED, false, Gravity.RIGHT);

        LinearLayout cleaner = makeCard(root);
        addText(cleaner, "تنظيف الملفات المؤقتة", 20, GOLD, true, Gravity.RIGHT);
        addText(cleaner,
                "اختر مجلدًا متاحًا لك. يفحص التطبيق ملفات .tmp و .temp و .log فقط، ويعرض النتائج قبل أي حذف.",
                13, MUTED, false, Gravity.RIGHT);
        folderLabel = addText(cleaner, "لم يتم اختيار مجلد بعد", 13, WHITE, false, Gravity.RIGHT);
        addButton(cleaner, "١ • اختيار مجلد", BLUE, this::chooseFolder);

        scanButton = addButton(cleaner, "٢ • فحص الملفات", GOLD, this::scan);
        scanButton.setEnabled(true);
        cleanButton = addButton(cleaner, "٣ • مراجعة وحذف الملفات", GOLD, this::confirmDelete);
        cleanButton.setEnabled(true);
        scanStatus = addText(cleaner, "١) اختر مجلدًا عاديًا متاحًا، ٢) افحصه، ثم ٣) راجع النتائج.", 14, WHITE, false, Gravity.RIGHT);

        LinearLayout notes = makeCard(root);
        addText(notes, "ملاحظات مهمة", 18, GOLD, true, Gravity.RIGHT);
        addText(notes,
                "• لا يحتاج التطبيق إلى Root.\n" +
                "• لا يمكنه تجاوز قيود أندرويد على مجلدات Android/data المحمية.\n" +
                "• راجع الملفات قبل الحذف؛ حذف السجلات قد يزيل معلومات تشخيصية.\n" +
                "• تغيير IP المحلي يتم من إعدادات الشبكة حسب الراوتر ومشغل الخدمة.",
                13, WHITE, false, Gravity.RIGHT);

        addButton(root, "تواصل مع المطور عبر Telegram", BLUE,
                () -> openUrl("https://t.me/OmarVIP3"));
        addText(root, "Abu Kayan • إصدار 1.1 تجريبي", 12, MUTED, false, Gravity.CENTER);
    }

    private LinearLayout makeCard(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(15), dp(15), dp(15));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        card.setBackground(round(CARD, dp(18), BLUE, 1));
        parent.addView(card, lp);
        return card;
    }

    private void refreshIpInfo() {
        if (refreshIpButton != null) refreshIpButton.setEnabled(false);
        localIpValue.setText("جارٍ قراءة IP الجهاز...");
        publicIpValue.setText("جارٍ جلب IP الإنترنت...");
        worker.execute(() -> {
            String local = readLocalIp();
            String external = readPublicIp();
            runOnUiThread(() -> {
                localIpValue.setText(local);
                publicIpValue.setText(external);
                if (refreshIpButton != null) refreshIpButton.setEnabled(true);
            });
        });
    }

    private String readLocalIp() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return "غير متاح — تحقق من الاتصال";
            while (interfaces.hasMoreElements()) {
                NetworkInterface network = interfaces.nextElement();
                try {
                    if (!network.isUp() || network.isLoopback()) continue;
                    Enumeration<InetAddress> addresses = network.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        InetAddress address = addresses.nextElement();
                        if (address instanceof Inet4Address && !address.isLoopbackAddress()
                                && !address.isLinkLocalAddress()) return address.getHostAddress();
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return "غير متاح — اتصل بالشبكة";
    }

    private String readPublicIp() {
        HttpsURLConnection connection = null;
        try {
            connection = (HttpsURLConnection) new URL("https://api.ipify.org").openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setUseCaches(false);
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                String ip = reader.readLine();
                if (ip != null && !ip.trim().isEmpty()) return ip.trim();
            }
        } catch (Exception ignored) {
            return "تعذر الجلب — تحقق من الإنترنت";
        } finally {
            if (connection != null) connection.disconnect();
        }
        return "غير متاح";
    }

    private void openWifiSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception ignored) { toast("تعذر فتح إعدادات Wi-Fi."); }
        }
    }

    private void openVpnSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_VPN_SETTINGS));
        } catch (Exception e) {
            toast("افتح إعدادات الهاتف ثم الشبكة والإنترنت ثم VPN.");
        }
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("تعذر فتح الرابط."); }
    }

    private void copyIp(String label, String value) {
        if (value == null || value.contains("جارٍ") || value.contains("غير متاح") || value.contains("تعذر")) {
            toast("لا يوجد عنوان جاهز للنسخ.");
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText(label, value));
            toast("تم نسخ " + label);
        }
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_FOLDER); }
        catch (Exception e) { scanStatus.setText("تعذر فتح اختيار المجلدات."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FOLDER || resultCode != RESULT_OK || data == null || data.getData() == null) return;

        folderUri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(folderUri, flags); }
        catch (SecurityException ignored) { }

        getSharedPreferences("cleaner", MODE_PRIVATE).edit().putString("folder", folderUri.toString()).apply();
        candidates.clear();
        cleanButton.setEnabled(true);
        scanButton.setEnabled(true);

        DocumentFile selected = DocumentFile.fromTreeUri(this, folderUri);
        folderLabel.setText(selected != null && selected.getName() != null
                ? "المجلد المحدد: " + selected.getName() : "تم اختيار المجلد بنجاح");
        scanStatus.setText("تم اختيار المجلد. اضغط فحص الملفات.");
    }

    private void scan() {
        if (folderUri == null) {
            scanStatus.setText("الخطوة الأولى: اضغط اختيار مجلد وحدد مجلدًا عاديًا مثل Download أو Documents.");
            toast("اختر مجلدًا أولًا من الزر رقم ١.");
            return;
        }
        scanButton.setEnabled(false);
        cleanButton.setEnabled(false);
        scanStatus.setText("جارٍ الفحص... اترك التطبيق مفتوحًا حتى تظهر النتيجة.");
        final Uri selectedUri = folderUri;

        worker.execute(() -> {
            ArrayList<DocumentFile> found = new ArrayList<>();
            int[] visited = {0};
            String error = null;
            try {
                DocumentFile root = DocumentFile.fromTreeUri(this, selectedUri);
                if (root == null || !root.canRead()) throw new SecurityException("Folder unavailable");
                walk(root, 0, visited, found);
            } catch (Exception e) {
                error = "تعذرت قراءة المجلد. اختر مجلدًا عاديًا متاحًا وأعد المحاولة.";
            }

            long bytes = 0;
            StringBuilder sample = new StringBuilder();
            for (int i = 0; i < found.size(); i++) {
                bytes += Math.max(0, found.get(i).length());
                if (i < 5) sample.append("\n• ").append(found.get(i).getName());
            }
            final String failure = error;
            final long total = bytes;
            final String examples = sample.toString();
            final int count = visited[0];

            runOnUiThread(() -> {
                if (!selectedUri.equals(folderUri)) return;
                candidates.clear();
                candidates.addAll(found);
                scanButton.setEnabled(true);
                cleanButton.setEnabled(true);
                if (failure != null) {
                    scanStatus.setText(failure + "\nقد يكون المجلد محميًا من أندرويد. جرّب Download أو Documents.");
                    toast("تعذر فحص هذا المجلد. جرّب مجلدًا آخر.");
                } else if (found.isEmpty()) {
                    scanStatus.setText("اكتمل الفحص: " + count + " عنصرًا. لم نعثر على ملفات .tmp أو .temp أو .log.\nلذلك لا توجد ملفات للحذف.");
                    toast("الفحص اكتمل ولم توجد ملفات مطابقة.");
                } else {
                    scanStatus.setText("اكتمل الفحص: " + count + " عنصرًا.\nالملفات المطابقة: "
                            + found.size() + "\nالحجم: " + humanSize(total) + examples
                            + "\nراجع النتائج ثم اضغط زر ٣ للمراجعة والحذف.");
                    toast("تم العثور على " + found.size() + " ملفًا للمراجعة.");
                }
            });
        });
    }

    private void walk(DocumentFile folder, int depth, int[] visited, ArrayList<DocumentFile> found) {
        if (depth > 8 || visited[0] >= 5000 || found.size() >= 1000) return;
        DocumentFile[] children;
        try { children = folder.listFiles(); }
        catch (Exception e) { return; }

        for (DocumentFile file : children) {
            if (++visited[0] > 5000 || found.size() >= 1000) return;
            if (file.isDirectory()) walk(file, depth + 1, visited, found);
            else if (file.isFile()) {
                String name = file.getName();
                if (name == null) continue;
                String lower = name.toLowerCase(Locale.ROOT);
                if (lower.endsWith(".tmp") || lower.endsWith(".temp") || lower.endsWith(".log")) found.add(file);
            }
        }
    }

    private void confirmDelete() {
        if (folderUri == null) {
            scanStatus.setText("ابدأ بالخطوة ١: اختر مجلدًا، ثم نفّذ فحص الملفات بالخطوة ٢.");
            toast("اختر مجلدًا وافحصه أولًا.");
            return;
        }
        if (candidates.isEmpty()) {
            scanStatus.setText("لا توجد ملفات جاهزة للحذف. اضغط الزر ٢ لفحص المجلد أولًا. إذا كانت نتيجة الفحص صفرًا، فلا توجد ملفات مطابقة.");
            toast("لا توجد ملفات للحذف حاليًا.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("تأكيد حذف الملفات")
                .setMessage("تم العثور على " + candidates.size()
                        + " ملفًا مؤقتًا أو ملف سجل. الحذف نهائي ولا يمكن التراجع. هل تريد المتابعة؟")
                .setNegativeButton("إلغاء", (dialog, which) -> { })
                .setPositiveButton("تأكيد الحذف", (dialog, which) -> deleteSelected())
                .show();
    }

    private void deleteSelected() {
        ArrayList<DocumentFile> deleting = new ArrayList<>(candidates);
        cleanButton.setEnabled(false);
        scanButton.setEnabled(false);
        scanStatus.setText("جارٍ حذف الملفات التي وافقت عليها...");
        worker.execute(() -> {
            int deleted = 0;
            for (DocumentFile file : deleting) {
                try { if (file.delete()) deleted++; }
                catch (Exception ignored) { }
            }
            final int done = deleted;
            runOnUiThread(() -> {
                candidates.clear();
                scanButton.setEnabled(folderUri != null);
                cleanButton.setEnabled(true);
                scanStatus.setText("انتهى الحذف: تم حذف " + done + " من أصل " + deleting.size()
                        + " ملف. أعد الفحص للتحقق.");
                toast("اكتملت عملية الحذف.");
            });
        });
    }

    private String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
    }

    private TextView addText(LinearLayout parent, String value, int size, int color, boolean bold, int gravity) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setGravity(gravity);
        text.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        text.setPadding(dp(4), dp(6), dp(4), dp(6));
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        parent.addView(text, new LinearLayout.LayoutParams(-1, -2));
        return text;
    }

    private Button addButton(LinearLayout parent, String label, int color, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTextColor(color == GOLD ? NAVY : WHITE);
        button.setBackground(round(color, dp(12), color, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(51));
        lp.topMargin = dp(9);
        parent.addView(button, lp);
        button.setOnClickListener(v -> action.run());
        return button;
    }

    private GradientDrawable round(int color, int radius, int borderColor, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (stroke > 0) drawable.setStroke(dp(stroke), borderColor);
        return drawable;
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override protected void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }
}

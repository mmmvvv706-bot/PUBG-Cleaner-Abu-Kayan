# PUBG Cleaner – Abu Kayan 1.2

- Displays the phone local IPv4 address and fetches the public IP over HTTPS.
- Opens Android Wi-Fi and VPN settings. The app cannot silently change the public IP; use a trusted VPN or change networks.
- Lets the user select an accessible folder and scans only `.tmp`, `.temp`, and `.log` files.
- The Scan and Review/Delete buttons remain tappable and explain missing prerequisites instead of appearing unresponsive.
- Deletion requires explicit confirmation.
- Android restricts access to protected locations such as `Android/data`; use a folder the user can grant access to, such as `Download` or `Documents`.
- No root access, game-file modification, or bypass of Android storage protections.

The GitHub Actions workflow builds `app-debug.apk` from this source archive.
